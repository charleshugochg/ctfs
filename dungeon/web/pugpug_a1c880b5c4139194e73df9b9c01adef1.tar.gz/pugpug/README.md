# PUGPUG

```bash
docker build . -t pugpug
docker run -p 3000:3000 -e FLAG=Neko{} pugpug
```   