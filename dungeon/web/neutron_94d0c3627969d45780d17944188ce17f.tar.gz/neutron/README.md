Download file from here: https://bsidesahm-web-files-blah-thisishash1234.s3.us-east-2.amazonaws.com/neutron-app_1.0.0_amd64.deb


```
docker-compose up
```

