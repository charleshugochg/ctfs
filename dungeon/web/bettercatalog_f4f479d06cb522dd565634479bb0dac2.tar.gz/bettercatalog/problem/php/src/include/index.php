<?php

error_reporting(0);

// This include must go first!  It includes some stuff like the CSP header and turning off error reporting.
include "utils.php";

include "db.php";
include "session.php";
include "header.php";
include "footer.php";
