<?php function make_footer() { ?>
</main>
</body>
</html>
<?php } ?>
