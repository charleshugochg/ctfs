#!/bin/bash

docker-compose exec mysql mysql -u mysql -D comic_catalog --password='blahblah'
