<pre><?php system('echo z_flag'); ?></pre>
